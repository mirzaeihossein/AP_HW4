#include"point.h"
#include<iostream>

//defenition of constructor
point::point(double X,double Y) : x{X} , y{Y} {}
