#ifndef STACK_H
#define STACK_H

template<class T>
class Stack
{
public:
	Stack();//constructor
	Stack(const Stack& stack);//copy constructor
	~Stack();//destructor
	void push(const T& rhs);//push function
	T& operator[](size_t index);
	Stack& operator=(const Stack& stack);
	int getCount();
	bool isEmpty();
	T pop(); 
	
//private:
	size_t cnt{};
	T* element{new T[cnt]};
 
};
#endif