#include<iostream>
#include<vector>
#include<string>
#include<functional>
#include<numeric>
#include<algorithm>
#include<cctype>
#include<set>

std::vector<int> remove_vector(std::vector<int>& v);//define own remove funcion
void myfunc(int& i)
{
	i = 2 * i;
}
int main()
{
	std::vector<int> vec{1,2,3,4,5,4,3,2,1};
	//print original vector
	std::cout << "original vector : " << std::endl;
	for(size_t i{};i < vec.size();i++)
	{
		if(i == vec.size()-1)
		std::cout << vec[i] << std::endl;
		else
		std::cout << vec[i] << ",";

	}
	std::cout << std::endl;
 	//***************************** Part A ***********************************

	//use std::remove() function
	std::vector <int>::iterator v;
	v = std::remove ( vec.begin(),vec.end(),2);
	//after remove() function
	std::cout << "after remove() function : " << std::endl;
	vec.erase(v,vec.end());
	for(size_t i{};i < vec.size();i++)
	{
		if(i == vec.size()-1)
		std::cout << vec[i] << std::endl;
		else
		std::cout << vec[i] << ",";
	}
	std::cout << std::endl;
	//************************************************************************
	//define remove function own
	vec={1,2,3,4,5,4,3,2,1};
	std::vector<int> remo;
	remo = remove_vector(vec);

	for(size_t i{};i < remo.size();i++)
	{
		if(i == remo.size()-1)
		std::cout << remo[i] << std::endl;
		else
		std::cout << remo[i] << ",";
	}
	std::cout << std::endl;
	//**************************** Part B ************************************
	vec={1,2,3,4,5,4,3,2,1};
	for_each(vec.begin(),vec.end(),myfunc);//multiple 2 each element
	std::cout << "multiple two : " << std::endl;
	for(size_t i{};i < vec.size();i++)
	{
		if(i == vec.size()-1)
		std::cout << vec[i] << std::endl;
		else
		std::cout << vec[i] << ",";
	}
	std::cout << std::endl;

	//**************************** Part C ************************************

	//**************************** Part D ************************************
	//remove repeted element
	std::cout << std::endl;
	vec={1,2,3,4,5,4,3,2,1};
	std::cout << "unique vector : ";
	std::sort(vec.begin(),vec.end());
	vec.erase(std::unique(vec.begin(),vec.end()),vec.end());
		for(size_t i{};i < vec.size();i++)
	{
		if(i == vec.size()-1)
		std::cout << vec[i] << std::endl;
		else
		std::cout << vec[i] << ",";

	}
	//**************************** Part E ***********************************
	//insert into set container
	vec={1,2,3,4,5,4,3,2,1};
	std::set<int> my_set;
	for(size_t i{};i < vec.size();i++)
	{
		my_set.insert(vec[i]);
	}
	std::cout << std::endl;
	std::cout << "set container : ";
	for(auto x : my_set)
		std::cout << x << " ,";
	std::cout << std::endl;
	//***********************************************************************
	//remove element upper than 3
	std::set<int>::iterator itup;
	itup=my_set.upper_bound(3);
	my_set.erase(itup,my_set.end());
	std::cout << std::endl;
	std::cout << "set after remove upper_bound(3) : ";
	for(auto x : my_set)
		std::cout << x << " ,";
	std::cout << std::endl;



	return 0;
}
std::vector<int> remove_vector(std::vector<int>& v)
{
	std::cout << "This is remove function that define own : " << std::endl;
	std::vector<int> temp;
	for(size_t i{};i < v.size();i++)
	{
		if(v[i] != 2)
			temp.push_back(v[i]);
	}
	return temp;
}