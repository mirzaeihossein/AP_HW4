#ifndef THREEDIMENSIONALSHAPE_H
#define THREEDIMENSIONALSHAPE_H
#include"shape.h"

class ThreeDimensionalShape : public shape
{
public:
	ThreeDimensionalShape(double a,double b);
	ThreeDimensionalShape()=default;
	//pure virtual function
	virtual double area() const =0;
	virtual double volume() const =0;
};

#endif