#ifndef SQUARE_H
#define SQUARE_H
#include"TwoDimensionalShape.h"
#include"point.h"

class Square : public TwoDimensionalShape
{
public:
	Square(double l,double a,double b);
	Square()=default;
	//define area
	double area() const override;
	//define print function
	virtual void print() const override;
	virtual Square& operator+(point& a);
protected:
	double length{1.0};
};




#endif