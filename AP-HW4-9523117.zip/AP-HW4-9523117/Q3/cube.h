#ifndef CUBE_H
#define CUBE_H
#include<iostream>
#include"ThreeDimensionalShape.h"
#include"point.h"

class Cube : public ThreeDimensionalShape
{
public:
	Cube(double l,double a,double b);
	Cube(double l);
	Cube()=default;
	//define volume and area
	virtual double area() const override;
	virtual double volume() const override;
	//define print function
	virtual void print() const override;
	virtual Cube& operator+(point& a);

protected:
	double side{1.0};
	double zo{1.0};

};

#endif