#include<iostream>
#include"sphere.h"
#include"ThreeDimensionalShape.h"
#include<math.h>
#include"point.h"


Sphere::Sphere(double r,double a,double b) : ThreeDimensionalShape(a,b)
{
	radius = r;
	zo = 0;
}
Sphere::Sphere(double r) : ThreeDimensionalShape(0,0)
{
	radius = r;
	zo = 0;
}
double Sphere::area() const
{
	double pi{std::acos(-1)};
	return 4*pi*(radius*radius);
}
double Sphere::volume() const
{
	double pi{std::acos(-1)};
	return 4.0*(1.0/3.0)*pi*(radius*radius*radius);
}
void Sphere::print() const
{
	std::cout << std::endl;
	std::cout << "Sphere radius = " << radius << std::endl;
	std::cout << "center -->" << "(" << xo << "," << yo << "," << zo << ")" << std::endl;
	std::cout << "area of " << area() << " & volume of " << volume() << std::endl; 
}
Sphere& Sphere::operator+(point& a)
{
	xo = xo + a.x;
	yo = yo + a.y;
	return *this;
}