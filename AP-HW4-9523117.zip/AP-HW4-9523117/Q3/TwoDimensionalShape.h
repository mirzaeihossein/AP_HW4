#ifndef TWODIMENSIONALSHAPE_H
#define TWODIMENSIONALSHAPE_H
#include<iostream>
#include"shape.h"

class TwoDimensionalShape : public shape
{
public:
	TwoDimensionalShape(double a,double b);//constructor
	TwoDimensionalShape()=default;
	//pure virtual function
	virtual double area() const =0;
};
#endif