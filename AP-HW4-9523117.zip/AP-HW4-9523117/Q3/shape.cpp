
#include"shape.h"
#include<iostream>
#include"point.h"

//constructor
shape::shape(double X,double Y) : xo{X} , yo{Y}
{
}
