#ifndef CTEXT_H
#define CTEXT_H
#include<iostream>
#include<string>

class CText
{
public:
	CText(std::string s);
	std::string& getText();//show sting that removed

private:
	std::string s{};
};
#endif