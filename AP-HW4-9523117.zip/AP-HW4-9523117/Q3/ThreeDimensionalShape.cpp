#include"shape.h"
#include"ThreeDimensionalShape.h"

ThreeDimensionalShape::ThreeDimensionalShape(double a,double b) : shape(a,b)
{
}