#include<iostream>
#include"square.h"
#include"TwoDimensionalShape.h"
#include"point.h"

Square::Square(double l,double a,double b) : TwoDimensionalShape(a,b)
{
	length = std::abs(l);
}
double Square::area() const
{
	return length*length;
}
void Square::print() const
{
	std::cout << std::endl;
	std::cout << "Square side length = " << length << std::endl;
	std::cout << "center-->" << " (" << xo << "," << yo << ")" << std::endl;
	std::cout << "area of " << area() << std::endl;
}
Square& Square::operator+(point& a)
{
	xo = xo + a.x;
	yo = yo + a.y;
	return *this;
}