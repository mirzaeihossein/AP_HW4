#ifndef POINT_H
#define POINT_H
#include<iostream>

class point
{
public:
point(double x, double y);//constructor
//get function
double getx(){return x;}
double gety(){return y;}
//set function
void setx(double a){x = a;}
void sety(double b){y = b;}

double x{1.0};
double y{1.0};
	
};
#endif