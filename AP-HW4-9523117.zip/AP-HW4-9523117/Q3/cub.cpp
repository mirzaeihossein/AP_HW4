#include<iostream>
#include"ThreeDimensionalShape.h"
#include"cube.h"
#include"point.h"

Cube::Cube(double s,double a,double b) : ThreeDimensionalShape(a,b)
{
	side = std::abs(s);
	zo=0;
}
Cube::Cube(double s) : ThreeDimensionalShape(0,0) 
{
	side = s;
	zo=0;
}
double Cube::area() const
{
	return 6.0*(side*side);
}
double Cube::volume() const
{
	return (side*side*side);
}
Cube& Cube::operator+(point& a)
{
	xo = xo + x.a;
	yo = yo + y.a;
}