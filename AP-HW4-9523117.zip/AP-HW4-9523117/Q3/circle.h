#ifndef CIRCLE_H
#define CIRCLE_H
#include"TwoDimensionalShape.h"
#include<math.h>
#include<cmath>
#include"point.h"

class Circle : public TwoDimensionalShape
{
public:
	Circle(double r,double a,double b);
	Circle()=default;
	//define area
	double area() const override;
	//define print function
	virtual void print() const override;
	virtual Circle& operator+(point& a);
protected:
	double radius{1.0};
};
#endif