#include<iostream>
#include"circle.h"
#include"TwoDimensionalShape.h"
#include<math.h>
#include<cmath>
#include"point.h"

Circle::Circle(double r,double a,double b) : TwoDimensionalShape(a,b)
{
	radius = r;
}
double Circle::area() const
{
	double pi{std::acos(-1)};
	return pi*(std::pow(radius,2));
}
void Circle::print() const 
{
	std::cout << std::endl;
	std:: cout << "Circle radius = " << radius << std::endl;
	std::cout << "center-->" << "(" << xo << "," << yo << ")" << std::endl;
	std::cout << "area of " << area() << std::endl;
}
Circle& Circle::operator+(point& a)
{
	xo = xo + a.x;
	yo = yo + a.y;
	return *this;
}