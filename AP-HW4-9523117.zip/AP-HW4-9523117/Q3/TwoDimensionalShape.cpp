#include"TwoDimensionalShape.h"
#include"shape.h"


TwoDimensionalShape::TwoDimensionalShape(double a,double b) : shape(a,b)
{
}
