#include<iostream>
#include"ctext.h"
#include<string>

CText::CText(std::string a)
{
	s = a;
}
std::string& CText::getText()
{
	return s;
}