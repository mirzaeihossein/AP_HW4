#include<iostream>
#include"stack.h"

template<class T>
Stack<T>::Stack()//constructor
{
	element = new T[cnt];
}

template<class T>
Stack<T>::Stack(const Stack& stack)//copy constructor
{
	element = new T[stack.cnt];
	for(int i{};i < stack.cnt ;i++)
		element[i] = stack.element[i];
}

template<class T>
void Stack<T>::push(const T& rhs)//push function
{
	cnt++;
	T* temp{new T[cnt]};
	for(size_t i{};i < cnt-1;i++)
		*(temp+i) = element[i];
	temp[cnt - 1] = rhs;
	this->element = temp;
	temp = nullptr;
	delete[] temp;
}

template<class T>
T Stack<T>::pop()//pop last element and show that
{
	T test{element[cnt-1]};
	cnt--;
	T* temp{new T[cnt]};
	for(size_t i{};i < cnt;i++)
		*(temp+i) = element[i];
	this->element = temp;
	temp = nullptr;
	delete[] temp;
	return test;
}

template<class T>
T& Stack<T>::operator[](size_t index)
{
	return element[index];
}

template<class T>
Stack<T>& Stack<T>::operator=(const Stack& stack)//operator = 
{
	delete[] element;
	cnt = stack.cnt;
	element = new T[cnt];
	for(int i{}; i < cnt;i++)
		element[i] = stack.element[i];
	return *this;
}

template<class T>
int Stack<T>::getCount()//number of T* element
{
	return cnt;
}

template<class T>
bool Stack<T>::isEmpty()
{
	if(cnt == 0)
		return true;
	else 
		return false;
}


template<class T>
Stack<T>::~Stack()//destructor
{
	delete[] element;
}