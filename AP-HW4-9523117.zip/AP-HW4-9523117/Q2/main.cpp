#include<iostream>
#include<utility>
#include<string>
#include<memory>
#include<vector>

template <typename T>
void show(std::vector<T>&);
int main()
{
	std::vector<std::unique_ptr<std::string>> v;//define unique_ptr
	for(int i{};i < 1000 ;i++)//insert data
	{
		std::string s{};
		if(i < 9)
		{
		s = "str 00"+ std::to_string(i);
		}
		else if( 9 < i && i < 100)
		{
		s = "str 0" + std::to_string(i);
		}
		else
		s = "str " + std::to_string(i);
		v.push_back(std::make_unique<std::string>(s));
		std::cout << s << " " ;
		show(v);//show function 
	}
	std::cout << "use cammand reserve : " << std::endl;
		std::vector<std::unique_ptr<std::string>> v1;
		v1.reserve(1000);//define reserve for constant capacity
	for(int i{};i < 1000 ;i++)//insert data
	{
		std::string s{};
		if(i < 9)
		{
		s = "str 00"+ std::to_string(i);
		}
		else if( 9 < i && i < 100)
		{
		s = "str 0" + std::to_string(i);
		}
		else
		s = "str " + std::to_string(i);
		v1.push_back(std::make_unique<std::string>(s));
		std::cout << s << " " ;
		show(v1);
	}
	
	
	return 0;
}
template <typename T>
void show(std::vector<T>& v)
{
	std::cout << "size : " << v.size() << "   capacity : " << v.capacity() << std::endl;
}