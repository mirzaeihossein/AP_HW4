#ifndef SPHERE_H
#define SPHERE_H
#include<iostream>
#include"ThreeDimensionalShape.h"
#include<math.h>
#include"point.h"


class Sphere : public ThreeDimensionalShape
{
public:
	Sphere(double r,double a,double b);//constructor
	Sphere()=default;
	Sphere(double r);//constructor with single input
	
	//define volume and area
	virtual double area() const override;
	virtual double volume() const override;
	//define print function
	virtual void print() const override;
	virtual Sphere& operator+(point& a);
protected:
	double radius{1.0};
	double zo{1.0};
};
#endif