#ifndef SHAPE_H
#define SHAPE_H

#include<iostream>
#include"point.h"
class shape
{
public:
shape(double a,double b);//constructor
shape() = default;
//get function
double getXO(){return xo;}
double getYO(){return yo;}
//set function
void setxo(double a){ xo = a ;}
void setyo(double b){ yo = b ;}
//virtual function
virtual void print() const = 0;
//operator
friend std::ostream& operator<< (std::ostream& out , shape& sh)
{
	sh.print();
	return out;
}
virtual shape& operator+ (point& a) =0 ;
protected:
//center of shape
double xo{1.0};
double yo{1.0};

};
#endif