#include<iostream>
#include<math.h>
#include"shape.h"
#include"ThreeDimensionalShape.h"
#include"TwoDimensionalShape.h"
#include"square.h"
#include"circle.h"
#include"cube.h"
#include"sphere.h"
#include"point.h"


int main()
{
	Square sqr{12,2,2};
	Circle cir{3.5,6,9};
	
	//use + operator
	point po{1,2};
	sqr.operator+(po);

	Cube cub{2.2};
	Sphere sph{5,1.5,4.5};
	shape* ptr[4] = { &cir , &sqr , &sph , &cub};
	for(int x{}; x < 4 ;++x)
	{
		std::cout << *(ptr[x]) << '\n';
	}

	return 0;
};