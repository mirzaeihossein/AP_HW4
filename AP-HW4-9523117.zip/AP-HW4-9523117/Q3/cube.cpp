#include<iostream>
#include"ThreeDimensionalShape.h"
#include"cube.h"
#include"point.h"

Cube::Cube(double s,double a,double b) : ThreeDimensionalShape(a,b)
{
	std::cout << "cub constructor" << std::endl;
	side = s;
	zo=0;
}
Cube::Cube(double s) : ThreeDimensionalShape(0,0) 
{
	side = s;
	zo=0;
}
double Cube::area() const
{
	return 6.0*(side*side);
}
double Cube::volume() const
{
	return (side*side*side);
}
void Cube::print() const
{
	std::cout << std::endl;
	std::cout << "Cube side length = " << side << std::endl;
	std::cout << "center -->" << "(" << xo << "," << yo << "," << zo << ")" << std::endl;
	std::cout << "area of " << area() << " & volume of " << volume() << std::endl;
}
Cube& Cube::operator+(point& a)
{
	xo = xo + a.x;
	yo = yo + a.y;
	return *this;
}